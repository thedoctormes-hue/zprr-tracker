import api from './client';

export const listPeople = () => api.get('/people');

export const getPersonDetails = (id: number) => api.get(`/people/${id}`);

export const createEdge = (from_id: number, to_id: number, type = 'similar') =>
  api.post('/edges', { from_id, to_id, relation_type: type });
