"""
ПРОТОКОЛ — FastAPI Core
v1.0 | Безумный Доктор
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.database import init_db
from app.routers import fragments, users, patterns


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(
    title="Протокол API",
    version="1.0.0",
    docs_url="/docs",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # TODO: сузить в проде
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router,     prefix="/api/v1/users",     tags=["users"])
app.include_router(fragments.router, prefix="/api/v1/fragments", tags=["fragments"])
app.include_router(patterns.router,  prefix="/api/v1/patterns",  tags=["patterns"])


@app.get("/health")
async def health():
    return {"status": "ok", "service": "протокол"}
