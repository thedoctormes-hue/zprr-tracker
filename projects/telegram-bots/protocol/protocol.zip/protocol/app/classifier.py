"""
Классификатор фрагментов памяти
Модель: Gemini 2.5 Flash через OpenRouter
Резерв: llama-3.3-70b:free
"""

import json
import httpx
from app.config import settings

CLASSIFY_PROMPT = """Ты — классификатор фрагментов памяти для системы "Протокол".

Твоя задача: принять текстовый фрагмент и вернуть ТОЛЬКО валидный JSON без markdown, без пояснений, без преамбул.

Схема ответа:
{
  "semantic_vector": {
    "task": 0.0,
    "idea": 0.0,
    "identity": 0.0,
    "knowledge": 0.0,
    "pattern": 0.0
  },
  "emotion": {
    "positive": 0.0,
    "negative": 0.0,
    "neutral": 0.0
  },
  "three_interpretations": [
    "через призму роста: ...",
    "через призму защиты: ...",
    "через призму связи: ..."
  ],
  "conflict_detected": false,
  "unknown_type": false,
  "people": [],
  "tags": [],
  "summary": "одно предложение — суть фрагмента",
  "confidence": 0.0,
  "meta": {}
}

Правила:
- Все числа от 0.0 до 1.0
- Сумма semantic_vector не обязана быть 1.0 — независимые веса
- Сумма emotion должна быть 1.0
- people — имена людей упомянутых в тексте (массив строк)
- tags — 2-5 смысловых тегов на русском
- confidence — уверенность в классификации
- conflict_detected: true если есть противоречие или внутренний конфликт
- unknown_type: true если не понимаешь что это
- three_interpretations — на русском, 1-2 предложения каждая
- summary — строго одно предложение на русском
- ТОЛЬКО JSON. Никакого текста до или после."""


async def classify_fragment(text: str) -> dict:
    """
    Классифицирует фрагмент.
    Пробует primary модель, при ошибке — fallback.
    """
    for model in [settings.llm_primary, settings.llm_fallback]:
        try:
            result = await _call_openrouter(text, model)
            return result
        except Exception as e:
            print(f"[classifier] {model} failed: {e}, trying next...")

    # Если оба упали — возвращаем заглушку с unknown_type
    return _fallback_result(text)


async def _call_openrouter(text: str, model: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.openrouter_api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": CLASSIFY_PROMPT},
                    {"role": "user", "content": text},
                ],
                "temperature": 0.3,
                "max_tokens": 800,
            },
        )
        response.raise_for_status()
        raw = response.json()["choices"][0]["message"]["content"]
        clean = raw.strip().removeprefix("```json").removesuffix("```").strip()
        return json.loads(clean)


def _fallback_result(text: str) -> dict:
    return {
        "semantic_vector": {"task": 0, "idea": 0, "identity": 0, "knowledge": 0, "pattern": 0},
        "emotion": {"positive": 0, "negative": 0, "neutral": 1.0},
        "three_interpretations": ["—", "—", "—"],
        "conflict_detected": False,
        "unknown_type": True,
        "people": [],
        "tags": [],
        "summary": "Классификация недоступна",
        "confidence": 0.0,
        "meta": {"error": "all_models_failed"},
    }
