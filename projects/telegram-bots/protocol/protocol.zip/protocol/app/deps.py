"""app/deps.py — зависимости FastAPI"""
from fastapi import Header, HTTPException, Depends
from app.database import get_db


async def get_current_user(
    x_tg_id: str = Header(..., alias="X-TG-ID"),
    db=Depends(get_db),
):
    """
    Простая авторизация через tg_id в заголовке.
    TODO: заменить на JWT или токен при релизе.
    """
    async with db.execute(
        "SELECT id, tg_id, plan, meta FROM users WHERE tg_id=?", (x_tg_id,)
    ) as cur:
        user = await cur.fetchone()

    if not user:
        raise HTTPException(401, "Пользователь не найден. Сначала /register")

    # Обновляем last_active_at
    await db.execute(
        "UPDATE users SET last_active_at=datetime('now') WHERE id=?", (user["id"],)
    )
    await db.commit()

    return dict(user)
