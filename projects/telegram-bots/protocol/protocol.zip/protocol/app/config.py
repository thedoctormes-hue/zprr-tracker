"""app/config.py"""
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    openrouter_api_key: str
    llm_primary: str = "google/gemini-2.5-flash"
    llm_fallback: str = "meta-llama/llama-3.3-70b-instruct:free"
    secret_key: str = "change-me-in-prod"

    class Config:
        env_file = ".env"

settings = Settings()
