"""
БД — SQLite + WAL + FTS5
Схема строго по мастер-документу v2.0
"""

import aiosqlite
from pathlib import Path

DB_PATH = Path("data/protocol.db")


async def get_db() -> aiosqlite.Connection:
    db = await aiosqlite.connect(DB_PATH)
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA foreign_keys=ON")
    return db


async def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA journal_mode=WAL")
        await db.execute("PRAGMA foreign_keys=ON")
        await db.executescript(SCHEMA)
        await db.commit()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id              TEXT PRIMARY KEY,           -- uuid
    tg_id           TEXT UNIQUE,
    encryption_key  TEXT,                       -- хэш токена
    plan            TEXT DEFAULT 'free',        -- free / paid / paid_plus
    created_at      TEXT DEFAULT (datetime('now')),
    last_active_at  TEXT DEFAULT (datetime('now')),
    meta            TEXT DEFAULT '{}'           -- JSON
);

CREATE TABLE IF NOT EXISTS memory_fragments (
    id                  TEXT PRIMARY KEY,
    user_id             TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text                TEXT NOT NULL,
    summary             TEXT,
    semantic_vector     TEXT DEFAULT '{}',      -- JSON
    emotion             TEXT DEFAULT '{}',      -- JSON
    three_interpretations TEXT DEFAULT '[]',    -- JSON
    conflict_detected   INTEGER DEFAULT 0,
    unknown_type        INTEGER DEFAULT 0,
    weight              REAL DEFAULT 1.0,       -- затухает
    privacy             TEXT DEFAULT 'private', -- private / trusted / public
    source              TEXT DEFAULT 'text',    -- voice / text / file
    confidence          REAL DEFAULT 0.0,
    created_at          TEXT DEFAULT (datetime('now')),
    last_accessed_at    TEXT DEFAULT (datetime('now')),
    meta                TEXT DEFAULT '{}'
);

CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    fragment_id,
    text,
    summary,
    content='memory_fragments',
    content_rowid='rowid'
);

CREATE TABLE IF NOT EXISTS memory_edges (
    id              TEXT PRIMARY KEY,
    from_id         TEXT NOT NULL REFERENCES memory_fragments(id) ON DELETE CASCADE,
    to_id           TEXT NOT NULL REFERENCES memory_fragments(id) ON DELETE CASCADE,
    weight          REAL DEFAULT 1.0,
    relation_type   TEXT,                       -- similar / contradicts / evolves / causes
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS people (
    id              TEXT PRIMARY KEY,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    alias           TEXT,
    role            TEXT,
    first_seen_at   TEXT DEFAULT (datetime('now')),
    meta            TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS people_edges (
    id          TEXT PRIMARY KEY,
    person_id   TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
    fragment_id TEXT NOT NULL REFERENCES memory_fragments(id) ON DELETE CASCADE,
    emotion     TEXT,
    context     TEXT,
    created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS patterns (
    id              TEXT PRIMARY KEY,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    description     TEXT NOT NULL,
    occurrences     INTEGER DEFAULT 1,
    first_seen_at   TEXT DEFAULT (datetime('now')),
    last_seen_at    TEXT DEFAULT (datetime('now')),
    meta            TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS exit_settings (
    user_id             TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    export_format       TEXT DEFAULT 'bundle',
    public_categories   TEXT DEFAULT '[]',
    trusted_tg_id       TEXT,
    auto_delete_days    INTEGER DEFAULT 90,
    farewell_message    TEXT,
    meta                TEXT DEFAULT '{}'
);

-- Индексы
CREATE INDEX IF NOT EXISTS idx_fragments_user     ON memory_fragments(user_id);
CREATE INDEX IF NOT EXISTS idx_fragments_weight   ON memory_fragments(weight DESC);
CREATE INDEX IF NOT EXISTS idx_fragments_created  ON memory_fragments(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_people_user        ON people(user_id);
CREATE INDEX IF NOT EXISTS idx_people_edges       ON people_edges(person_id, fragment_id);
CREATE INDEX IF NOT EXISTS idx_memory_edges_from  ON memory_edges(from_id);
CREATE INDEX IF NOT EXISTS idx_patterns_user      ON patterns(user_id, last_seen_at DESC);

-- Триггер: FTS синхронизация
CREATE TRIGGER IF NOT EXISTS fts_insert AFTER INSERT ON memory_fragments BEGIN
    INSERT INTO memory_fts(fragment_id, text, summary)
    VALUES (new.id, new.text, COALESCE(new.summary, ''));
END;

CREATE TRIGGER IF NOT EXISTS fts_delete AFTER DELETE ON memory_fragments BEGIN
    DELETE FROM memory_fts WHERE fragment_id = old.id;
END;
"""
